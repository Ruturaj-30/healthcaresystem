"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { IOSHeader } from "@/components/ios-header"
import { IOSTabBar } from "@/components/ios-tab-bar"
import { Shield, FileText, Lock, Fingerprint } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

export default function Home() {
  const [userType, setUserType] = useState<"patient" | "hospital" | "none">("none")
  const { translations } = useLanguage()

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("medchain_user")
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData)
        setUserType(parsedUser.isPatient ? "patient" : "hospital")
      } catch (error) {
        setUserType("none")
      }
    }
  }, [])

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50 to-white">
      <IOSHeader title={translations.app_name} />

      <main className="flex-1 px-4 py-6 pb-24">
        {" "}
        {/* Added pb-24 for tab bar space */}
        <div className="mb-8 text-center">
          <div className="mb-4 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-blue-100">
              <Shield className="h-10 w-10 text-blue-600" />
            </div>
          </div>
          <h1 className="mb-2 text-3xl font-bold tracking-tight text-gray-900">{translations.app_name}</h1>
          <p className="mx-auto max-w-2xl text-base text-gray-600">{translations.welcome}</p>
        </div>
        <div className="mt-8 space-y-6">
          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="h-2 bg-gradient-to-r from-blue-400 to-blue-600"></div>
            <CardHeader className="bg-blue-50 pb-4">
              <CardTitle className="text-xl">{translations.for_patients}</CardTitle>
              <CardDescription>{translations.register_manage}</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ul className="mb-6 space-y-4">
                <li className="flex items-start">
                  <div className="mr-3 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-blue-100">
                    <Shield className="h-3.5 w-3.5 text-blue-600" />
                  </div>
                  <div>
                    <span className="font-medium">{translations.secure_medical_id}</span>
                    <p className="text-sm text-gray-600">{translations.secure_medical_id_desc}</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-3 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-blue-100">
                    <Lock className="h-3.5 w-3.5 text-blue-600" />
                  </div>
                  <div>
                    <span className="font-medium">{translations.control_data}</span>
                    <p className="text-sm text-gray-600">{translations.control_data_desc}</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-3 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-blue-100">
                    <Fingerprint className="h-3.5 w-3.5 text-blue-600" />
                  </div>
                  <div>
                    <span className="font-medium">{translations.face_id_auth}</span>
                    <p className="text-sm text-gray-600">{translations.face_id_auth_desc}</p>
                  </div>
                </li>
              </ul>
            </CardContent>
            <CardFooter className="bg-gray-50 px-6 py-4">
              <Link href="/patient/register" className="w-full">
                <Button className="w-full rounded-full bg-gradient-to-r from-blue-500 to-blue-600 py-6 text-base shadow-md transition-transform hover:scale-[1.02] hover:shadow-lg">
                  {translations.register_patient}
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="h-2 bg-gradient-to-r from-green-400 to-green-600"></div>
            <CardHeader className="bg-green-50 pb-4">
              <CardTitle className="text-xl">{translations.for_hospitals}</CardTitle>
              <CardDescription>{translations.upload_access}</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ul className="mb-6 space-y-4">
                <li className="flex items-start">
                  <div className="mr-3 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-100">
                    <FileText className="h-3.5 w-3.5 text-green-600" />
                  </div>
                  <div>
                    <span className="font-medium">{translations.secure_uploads}</span>
                    <p className="text-sm text-gray-600">{translations.secure_uploads_desc}</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-3 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-3.5 w-3.5 text-green-600"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                    </svg>
                  </div>
                  <div>
                    <span className="font-medium">{translations.patient_history}</span>
                    <p className="text-sm text-gray-600">{translations.patient_history_desc}</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="mr-3 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-100">
                    <Fingerprint className="h-3.5 w-3.5 text-green-600" />
                  </div>
                  <div>
                    <span className="font-medium">{translations.staff_auth}</span>
                    <p className="text-sm text-gray-600">{translations.staff_auth_desc}</p>
                  </div>
                </li>
              </ul>
            </CardContent>
            <CardFooter className="bg-gray-50 px-6 py-4">
              <Link href="/hospital/login" className="w-full">
                <Button className="w-full rounded-full bg-gradient-to-r from-green-500 to-green-600 py-6 text-base shadow-md transition-transform hover:scale-[1.02] hover:shadow-lg">
                  {translations.hospital_login}
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </main>

      <IOSTabBar userType={userType} />
    </div>
  )
}
