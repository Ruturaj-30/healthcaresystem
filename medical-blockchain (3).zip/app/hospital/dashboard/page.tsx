"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileIcon, SearchIcon, UploadIcon, ExternalLink, Building2, Mail, Phone } from "lucide-react"
import { PatientSearch } from "@/components/patient-search"
import { FileUpload } from "@/components/file-upload"
import { IOSHeader } from "@/components/ios-header"
import { IOSTabBar } from "@/components/ios-tab-bar"
import { useLanguage } from "@/lib/language-context"

interface User {
  name: string
  hospitalId: string
  isPatient: boolean
  email?: string
  phone?: string
}

export default function HospitalDashboard() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("search")
  const { translations } = useLanguage()

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("medchain_user")
    if (!userData) {
      router.push("/hospital/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (parsedUser.isPatient) {
        router.push("/")
        return
      }
      setUser(parsedUser)
    } catch (error) {
      router.push("/hospital/login")
    } finally {
      setLoading(false)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("medchain_user")
    router.push("/")
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-white">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-blue-200 border-t-blue-600"></div>
          <p>{translations.loading}</p>
        </div>
      </div>
    )
  }

  if (!user) return null

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50 to-white">
      <IOSHeader title={translations.dashboard} isLoggedIn={true} onLogout={handleLogout} userType="hospital" />

      <main className="flex-1 px-4 py-6 pb-24">
        {" "}
        {/* Added pb-24 for tab bar space */}
        <div className="mb-8 grid gap-6 md:grid-cols-3">
          <Card className="overflow-hidden border-0 shadow-lg md:col-span-2">
            <div className="h-2 bg-gradient-to-r from-green-400 to-green-600"></div>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center justify-between">
                <span>{translations.hospital_profile}</span>
                <Link href="/hospital/profile">
                  <Button variant="ghost" size="sm" className="h-8 gap-1 rounded-full text-green-600">
                    <span className="text-sm">{translations.edit}</span>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </Button>
                </Link>
              </CardTitle>
              <CardDescription>{translations.hospital_info}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center">
                  <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-green-100">
                    <Building2 className="h-4 w-4 text-green-600" />
                  </div>
                  <span>{user.name}</span>
                </div>
                {user.email && (
                  <div className="flex items-center">
                    <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-green-100">
                      <Mail className="h-4 w-4 text-green-600" />
                    </div>
                    <span className="truncate">{user.email}</span>
                  </div>
                )}
                {user.phone && (
                  <div className="flex items-center">
                    <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-green-100">
                      <Phone className="h-4 w-4 text-green-600" />
                    </div>
                    <span>{user.phone}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="h-2 bg-gradient-to-r from-green-400 to-green-600"></div>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{translations.hospital_id}</CardTitle>
              <CardDescription>{translations.hospital_identifier}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between rounded-lg bg-green-50 p-3">
                <code className="text-sm font-mono overflow-x-auto max-w-[180px] md:max-w-full">{user.hospitalId}</code>
                <button
                  className="ml-2 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white shadow-sm"
                  onClick={() => navigator.clipboard.writeText(user.hospitalId)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 text-green-600"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                  </svg>
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
        <Card className="mb-6 overflow-hidden border-0 shadow-lg">
          <div className="h-2 bg-gradient-to-r from-green-400 to-green-600"></div>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Quick Actions</CardTitle>
            <CardDescription>Manage patient records</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                className="rounded-full border-green-200 text-green-700 hover:bg-green-50 hover:text-green-800"
              >
                <SearchIcon className="mr-2 h-4 w-4" />
                {translations.patient_search}
              </Button>
              <Button
                variant="outline"
                className="rounded-full border-green-200 text-green-700 hover:bg-green-50 hover:text-green-800"
              >
                <UploadIcon className="mr-2 h-4 w-4" />
                {translations.upload_records}
              </Button>
              <Button
                variant="outline"
                className="rounded-full border-green-200 text-green-700 hover:bg-green-50 hover:text-green-800"
              >
                <FileIcon className="mr-2 h-4 w-4" />
                View Recent Uploads
              </Button>
            </div>
          </CardContent>
        </Card>
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 rounded-xl">
            <TabsTrigger value="search">{translations.patient_search}</TabsTrigger>
            <TabsTrigger value="upload">{translations.upload_records}</TabsTrigger>
          </TabsList>
          <TabsContent value="search" className="mt-6">
            <PatientSearch hospitalId={user.hospitalId} />
          </TabsContent>
          <TabsContent value="upload" className="mt-6">
            <FileUpload hospitalId={user.hospitalId} />
          </TabsContent>
        </Tabs>
      </main>

      <IOSTabBar userType="hospital" />
    </div>
  )
}
