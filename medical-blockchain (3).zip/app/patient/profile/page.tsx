"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Loader2, User, Mail, Phone, Key, Fingerprint } from "lucide-react"
import { IOSHeader } from "@/components/ios-header"
import { IOSTabBar } from "@/components/ios-tab-bar"
import { useToast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { useLanguage } from "@/lib/language-context"

interface UserProfile {
  name: string
  email: string
  phone: string
  uniqueId: string
  isPatient: boolean
  useFaceID: boolean
}

export default function PatientProfile() {
  const router = useRouter()
  const { toast } = useToast()
  const { translations } = useLanguage()
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [profile, setProfile] = useState<UserProfile>({
    name: "",
    email: "",
    phone: "",
    uniqueId: "",
    isPatient: true,
    useFaceID: false,
  })

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("medchain_user")
    if (!userData) {
      router.push("/patient/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isPatient) {
        router.push("/")
        return
      }

      // Set default phone if not present
      if (!parsedUser.phone) {
        parsedUser.phone = ""
      }

      // Handle legacy data that might still have blockchainId
      if (parsedUser.blockchainId && !parsedUser.uniqueId) {
        parsedUser.uniqueId = parsedUser.blockchainId
      }

      setProfile(parsedUser)
    } catch (error) {
      router.push("/patient/login")
    } finally {
      setIsLoading(false)
    }
  }, [router])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProfile((prev) => ({ ...prev, [name]: value }))
  }

  const handleFaceIDToggle = (checked: boolean) => {
    setProfile((prev) => ({ ...prev, useFaceID: checked }))
  }

  const handleSave = async () => {
    setIsSaving(true)

    try {
      // Validate phone number
      if (profile.phone && !/^\+?[0-9\s\-()]{7,15}$/.test(profile.phone)) {
        toast({
          title: "Invalid phone number",
          description: "Please enter a valid phone number",
          variant: "destructive",
        })
        setIsSaving(false)
        return
      }

      // Simulate saving
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Update local storage
      localStorage.setItem("medchain_user", JSON.stringify(profile))

      toast({
        title: translations.profile_updated,
        description: translations.profile_updated,
      })
    } catch (err) {
      toast({
        title: "Update failed",
        description: "An error occurred while updating your profile",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("medchain_user")
    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-white">
        <div className="text-center">
          <div className="mb-4 h-10 w-10 animate-spin rounded-full border-4 border-blue-200 border-t-blue-600"></div>
          <p>{translations.loading}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50 to-white">
      <IOSHeader
        title={translations.profile}
        showBackButton
        backUrl="/patient/dashboard"
        isLoggedIn={true}
        onLogout={handleLogout}
        userType="patient"
      />

      <main className="flex-1 px-4 py-6 pb-24">
        {" "}
        {/* Added pb-24 for tab bar space */}
        <div className="mb-6 flex justify-center">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-blue-100 text-blue-600">
            <User className="h-12 w-12" />
          </div>
        </div>
        <Card className="mb-6 border-0 shadow-lg">
          <CardHeader>
            <CardTitle>{translations.personal_info}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="flex items-center gap-2">
                <User className="h-4 w-4 text-blue-600" /> {translations.full_name}
              </Label>
              <Input
                id="name"
                name="name"
                value={profile.name}
                onChange={handleChange}
                className="rounded-xl border-gray-300 bg-white shadow-sm"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-blue-600" /> {translations.email}
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={profile.email}
                onChange={handleChange}
                className="rounded-xl border-gray-300 bg-white shadow-sm"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-blue-600" /> {translations.phone}
              </Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={profile.phone}
                onChange={handleChange}
                className="rounded-xl border-gray-300 bg-white shadow-sm"
              />
            </div>
          </CardContent>
        </Card>
        <Card className="mb-6 border-0 shadow-lg">
          <CardHeader>
            <CardTitle>{translations.medical_id}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="uniqueId" className="flex items-center gap-2">
                <Key className="h-4 w-4 text-blue-600" /> {translations.unique_id}
              </Label>
              <div className="flex items-center rounded-xl bg-gray-50 p-3 text-sm font-mono">
                <div className="overflow-x-auto">{profile.uniqueId}</div>
                <button
                  className="ml-2 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white shadow-sm"
                  onClick={() => {
                    navigator.clipboard.writeText(profile.uniqueId)
                    toast({
                      title: translations.copied,
                      description: translations.copied,
                    })
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 text-blue-600"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                  </svg>
                </button>
              </div>
              <p className="mt-2 text-xs text-gray-500">
                This is your unique identifier in our system. Share it with healthcare providers to grant them access to
                your records.
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="mb-6 border-0 shadow-lg">
          <CardHeader>
            <CardTitle>{translations.security_settings}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Fingerprint className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">{translations.face_id_auth}</p>
                  <p className="text-sm text-gray-500">{translations.face_id_toggle}</p>
                </div>
              </div>
              <Switch checked={profile.useFaceID} onCheckedChange={handleFaceIDToggle} />
            </div>
          </CardContent>
        </Card>
        <div className="space-y-4">
          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="w-full rounded-full bg-gradient-to-r from-blue-500 to-blue-600 py-6 text-base shadow-md transition-transform hover:scale-[1.02] hover:shadow-lg"
          >
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {translations.saving}
              </>
            ) : (
              translations.save_changes
            )}
          </Button>

          <Button
            variant="outline"
            onClick={handleLogout}
            className="w-full rounded-full border-red-200 py-6 text-base text-red-600 hover:bg-red-50 hover:text-red-700"
          >
            {translations.logout}
          </Button>
        </div>
      </main>

      <IOSTabBar userType="patient" />
      <Toaster />
    </div>
  )
}
