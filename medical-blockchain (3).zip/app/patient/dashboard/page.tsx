"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { UserIcon, Phone, Mail, ExternalLink } from "lucide-react"
import { AccessControl } from "@/components/access-control"
import { MedicalRecords } from "@/components/medical-records"
import { IOSHeader } from "@/components/ios-header"
import { IOSTabBar } from "@/components/ios-tab-bar"
import { useLanguage } from "@/lib/language-context"

interface User {
  name: string
  email: string
  phone?: string
  uniqueId?: string
  blockchainId?: string // For backward compatibility
  isPatient: boolean
}

export default function PatientDashboard() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("records")
  const { translations } = useLanguage()

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("medchain_user")
    if (!userData) {
      router.push("/patient/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      if (!parsedUser.isPatient) {
        router.push("/")
        return
      }

      // Handle legacy data that might still have blockchainId
      if (parsedUser.blockchainId && !parsedUser.uniqueId) {
        parsedUser.uniqueId = parsedUser.blockchainId
      }

      setUser(parsedUser)
    } catch (error) {
      router.push("/patient/login")
    } finally {
      setLoading(false)
    }
  }, [router])

  useEffect(() => {
    const tab = searchParams.get("tab")
    if (tab === "records" || tab === "access") {
      setActiveTab(tab)
    }
  }, [searchParams])

  const handleLogout = () => {
    localStorage.removeItem("medchain_user")
    router.push("/")
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-white">
        <div className="text-center">
          <div className="mb-4 h-10 w-10 animate-spin rounded-full border-4 border-blue-200 border-t-blue-600"></div>
          <p>{translations.loading}</p>
        </div>
      </div>
    )
  }

  if (!user) return null

  const userId = user.uniqueId || user.blockchainId || ""

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50 to-white">
      <IOSHeader title={translations.dashboard} isLoggedIn={true} onLogout={handleLogout} userType="patient" />

      <main className="flex-1 px-4 py-6 pb-24">
        {" "}
        {/* Added pb-24 for tab bar space */}
        <div className="mb-6 space-y-4">
          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="h-2 bg-gradient-to-r from-blue-400 to-blue-600"></div>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center justify-between">
                <span>{translations.personal_profile}</span>
                <Link href="/patient/profile">
                  <Button variant="ghost" size="sm" className="h-8 gap-1 rounded-full text-blue-600">
                    <span className="text-sm">{translations.edit}</span>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </Button>
                </Link>
              </CardTitle>
              <CardDescription>{translations.personal_info}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center">
                  <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                    <UserIcon className="h-4 w-4 text-blue-600" />
                  </div>
                  <span>{user.name}</span>
                </div>
                <div className="flex items-center">
                  <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                    <Mail className="h-4 w-4 text-blue-600" />
                  </div>
                  <span className="truncate">{user.email}</span>
                </div>
                {user.phone && (
                  <div className="flex items-center">
                    <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                      <Phone className="h-4 w-4 text-blue-600" />
                    </div>
                    <span>{user.phone}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="h-2 bg-gradient-to-r from-blue-400 to-blue-600"></div>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{translations.medical_id}</CardTitle>
              <CardDescription>{translations.unique_id}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between rounded-lg bg-blue-50 p-3">
                <code className="text-sm font-mono overflow-x-auto max-w-[180px] md:max-w-full">{userId}</code>
                <button
                  className="ml-2 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white shadow-sm"
                  onClick={() => {
                    navigator.clipboard.writeText(userId)
                    // You could add a toast notification here
                  }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 text-blue-600"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                  </svg>
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 rounded-xl">
            <TabsTrigger value="records" className="rounded-l-xl">
              {translations.medical_records}
            </TabsTrigger>
            <TabsTrigger value="access" className="rounded-r-xl">
              {translations.access_control}
            </TabsTrigger>
          </TabsList>
          <TabsContent value="records" className="mt-6">
            <MedicalRecords patientId={userId} />
          </TabsContent>
          <TabsContent value="access" className="mt-6">
            <AccessControl patientId={userId} />
          </TabsContent>
        </Tabs>
      </main>

      <IOSTabBar userType="patient" />
    </div>
  )
}
