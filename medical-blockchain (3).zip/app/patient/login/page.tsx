"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, Fingerprint } from "lucide-react"
import { IOSHeader } from "@/components/ios-header"
import { IOSTabBar } from "@/components/ios-tab-bar"
import { FaceIDAuth } from "@/components/face-id-auth"

export default function PatientLogin() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const [error, setError] = useState("")
  const [showFaceID, setShowFaceID] = useState(false)
  const [faceIDAvailable, setFaceIDAvailable] = useState(false)

  useEffect(() => {
    // Check if user has previously logged in (for Face ID availability)
    const userData = localStorage.getItem("medchain_user")
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData)
        if (parsedUser.isPatient) {
          setFaceIDAvailable(true)
          // Auto-prompt for Face ID after a short delay
          const timer = setTimeout(() => {
            setShowFaceID(true)
          }, 500)
          return () => clearTimeout(timer)
        }
      } catch (error) {
        console.error("Error parsing user data:", error)
      }
    }
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Simulate login
    try {
      // In a real app, this would verify credentials and retrieve blockchain identity
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // For demo purposes, create a mock user if none exists
      if (!localStorage.getItem("medchain_user")) {
        const blockchainId = "0x" + Math.random().toString(16).slice(2, 10) + Math.random().toString(16).slice(2, 10)
        localStorage.setItem(
          "medchain_user",
          JSON.stringify({
            name: "Demo Patient",
            email: formData.email,
            blockchainId,
            isPatient: true,
            useFaceID: true,
          }),
        )
      }

      router.push("/patient/dashboard")
    } catch (err) {
      setError("Login failed. Please check your credentials.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleFaceIDAuthentication = async () => {
    setIsLoading(true)
    try {
      // In a real app, this would verify biometric authentication
      await new Promise((resolve) => setTimeout(resolve, 1000))
      router.push("/patient/dashboard")
    } catch (err) {
      setError("Face ID authentication failed. Please try again or use password.")
      setShowFaceID(false)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 pb-14">
      <IOSHeader title="Patient Login" showBackButton backUrl="/" />

      <main className="flex flex-1 items-center justify-center p-4">
        <Card className="w-full max-w-md border-0 shadow-lg">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold">Patient Login</CardTitle>
            <CardDescription>Access your medical records on the blockchain</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="john@example.com"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="ios-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  className="ios-input"
                />
              </div>
              {error && <p className="text-sm font-medium text-red-500">{error}</p>}

              {faceIDAvailable && !showFaceID && (
                <Button
                  type="button"
                  variant="outline"
                  className="w-full flex items-center justify-center gap-2 rounded-full"
                  onClick={() => setShowFaceID(true)}
                >
                  <Fingerprint className="h-4 w-4" />
                  <span>Sign in with Face ID</span>
                </Button>
              )}
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button className="w-full ios-button" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Logging in...
                  </>
                ) : (
                  "Login"
                )}
              </Button>
              <div className="text-center text-sm">
                Don&apos;t have an account?{" "}
                <Link href="/patient/register" className="text-blue-600 hover:underline">
                  Register
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </main>

      {showFaceID && <FaceIDAuth onAuthenticate={handleFaceIDAuthentication} onCancel={() => setShowFaceID(false)} />}

      <IOSTabBar userType="none" />
    </div>
  )
}
