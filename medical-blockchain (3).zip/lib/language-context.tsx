"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { en } from "./translations/en"
import { hi } from "./translations/hi"
import { mr } from "./translations/mr"

type Translations = typeof en

type LanguageContextType = {
  language: string
  translations: Translations
  setLanguage: (lang: string) => void
}

const translations = {
  en,
  hi,
  mr,
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState("en")
  const [currentTranslations, setCurrentTranslations] = useState<Translations>(translations.en)

  useEffect(() => {
    // Load saved language preference from localStorage
    const savedLanguage = localStorage.getItem("medchain_language")
    if (savedLanguage && ["en", "hi", "mr"].includes(savedLanguage)) {
      setLanguageState(savedLanguage)
      setCurrentTranslations(translations[savedLanguage as keyof typeof translations])
    }
  }, [])

  const setLanguage = (lang: string) => {
    if (["en", "hi", "mr"].includes(lang)) {
      setLanguageState(lang)
      setCurrentTranslations(translations[lang as keyof typeof translations])
      localStorage.setItem("medchain_language", lang)
    }
  }

  return (
    <LanguageContext.Provider
      value={{
        language,
        translations: currentTranslations,
        setLanguage,
      }}
    >
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
