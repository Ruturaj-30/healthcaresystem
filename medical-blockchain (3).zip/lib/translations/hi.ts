export const hi = {
  // Common
  app_name: "मेडचेन",
  loading: "लोड हो रहा है...",
  save: "सहेजें",
  cancel: "रद्द करें",
  edit: "संपादित करें",
  delete: "हटाएं",
  logout: "साइन आउट",
  copy: "कॉपी करें",
  copied: "क्लिपबोर्ड पर कॉपी किया गया",

  // Home page
  welcome: "रोगी चिकित्सा रिकॉर्ड प्रबंधित करने के लिए एक सुरक्षित प्रणाली",
  for_patients: "रोगियों के लिए",
  register_manage: "पंजीकरण करें और अपने चिकित्सा रिकॉर्ड प्रबंधित करें",
  secure_medical_id: "सुरक्षित मेडिकल आईडी",
  secure_medical_id_desc: "आपका मेडिकल डेटा उन्नत एन्क्रिप्शन द्वारा संरक्षित",
  control_data: "अपने डेटा को नियंत्रित करें",
  control_data_desc: "अपने मेडिकल रिकॉर्ड तक पहुंच प्रदान करें और रद्द करें",
  face_id_auth: "फेस आईडी प्रमाणीकरण",
  face_id_auth_desc: "अपने स्वास्थ्य डेटा तक सुरक्षित और सुविधाजनक पहुंच",
  register_patient: "रोगी के रूप में पंजीकरण करें",

  for_hospitals: "अस्पतालों के लिए",
  upload_access: "रोगी रिकॉर्ड अपलोड और एक्सेस करें",
  secure_uploads: "सुरक्षित रिकॉर्ड अपलोड",
  secure_uploads_desc: "रोगी चिकित्सा रिकॉर्ड आसानी से अपलोड और प्रबंधित करें",
  patient_history: "रोगी इतिहास तक पहुंच",
  patient_history_desc: "रोगी की अनुमति से पूर्ण चिकित्सा इतिहास देखें",
  staff_auth: "स्टाफ प्रमाणीकरण",
  staff_auth_desc: "अधिकृत कर्मियों के लिए सुरक्षित बायोमेट्रिक पहुंच",
  hospital_login: "अस्पताल लॉगिन",

  // Dashboard
  dashboard: "डैशबोर्ड",
  personal_profile: "व्यक्तिगत प्रोफाइल",
  personal_info: "आपकी व्यक्तिगत जानकारी",
  hospital_profile: "अस्पताल प्रोफाइल",
  hospital_info: "आपकी अस्पताल जानकारी",
  medical_id: "मेडिकल आईडी",
  unique_id: "आपका विशिष्ट पहचानकर्ता",
  hospital_id: "अस्पताल आईडी",
  hospital_identifier: "आपका अस्पताल पहचानकर्ता",

  // Medical Records
  medical_records: "चिकित्सा रिकॉर्ड",
  no_records: "कोई चिकित्सा रिकॉर्ड नहीं मिला",
  no_records_desc: "आपके पास अभी तक कोई चिकित्सा रिकॉर्ड नहीं है।",
  all: "सभी",
  diagnosis: "निदान",
  prescription: "नुस्खा",
  lab_results: "लैब परिणाम",
  imaging: "इमेजिंग",

  // Access Control
  access_control: "एक्सेस कंट्रोल",
  pending_requests: "लंबित एक्सेस अनुरोध",
  hospitals_with_access: "एक्सेस वाले अस्पताल",
  active: "सक्रिय",
  no_access: "कोई एक्सेस नहीं दिया गया",
  no_access_desc: "आपने अभी तक किसी भी अस्पताल को अपने चिकित्सा रिकॉर्ड तक पहुंच नहीं दी है।",
  security: "सुरक्षा",
  security_desc:
    "आपकी एक्सेस कंट्रोल सेटिंग्स सुरक्षित रूप से संग्रहीत हैं। केवल आप ही अपने चिकित्सा रिकॉर्ड तक पहुंच प्रदान या रद्द कर सकते हैं।",
  approve: "स्वीकृत करें",
  deny: "अस्वीकार करें",

  // Patient Search
  patient_search: "रोगी खोज",
  search: "खोजें",
  enter_patient_id: "रोगी आईडी दर्ज करें",
  patient_not_found: "रोगी नहीं मिला। कृपया आईडी जांचें।",
  access_required: "एक्सेस आवश्यक",
  access_required_desc:
    "आपको इस रोगी के चिकित्सा रिकॉर्ड देखने के लिए अनुमति की आवश्यकता है। एक्सेस का अनुरोध करें और रोगी को सूचित किया जाएगा।",
  request_access: "एक्सेस का अनुरोध करें",
  access_granted: "एक्सेस प्रदान किया गया",
  access_requested: "एक्सेस का अनुरोध किया गया",

  // File Upload
  upload_records: "चिकित्सा रिकॉर्ड अपलोड करें",
  upload_desc: "रोगी रिकॉर्ड सुरक्षित रूप से हमारी प्रणाली में अपलोड करें",
  patient_id: "रोगी आईडी",
  record_type: "रिकॉर्ड प्रकार",
  record_title: "रिकॉर्ड शीर्षक",
  description: "विवरण (वैकल्पिक)",
  files: "फाइलें",
  tap_upload: "अपलोड करने के लिए टैप करें",
  file_formats: "PDF, DOC, JPG, PNG, DICOM और अन्य चिकित्सा प्रारूप",
  take_photo: "फोटो लें",
  uploading: "अपलोड हो रहा है...",
  upload_success: "चिकित्सा रिकॉर्ड सफलतापूर्वक अपलोड किए गए हैं।",

  // Profile
  profile: "प्रोफाइल",
  full_name: "पूरा नाम",
  email: "ईमेल पता",
  phone: "मोबाइल नंबर",
  hospital_name: "अस्पताल का नाम",
  address: "पता",
  security_settings: "सुरक्षा सेटिंग्स",
  face_id_toggle: "त्वरित और सुरक्षित लॉगिन के लिए फेस आईडी का उपयोग करें",
  save_changes: "परिवर्तन सहेजें",
  saving: "सहेज रहा है...",
  profile_updated: "आपकी प्रोफाइल सफलतापूर्वक अपडेट की गई है",

  // Language
  language: "भाषा",
  english: "English",
  hindi: "हिंदी",
  marathi: "मराठी",
  select_language: "भाषा चुनें",
  language_changed: "भाषा सफलतापूर्वक बदली गई",

  // Advanced Healthcare
  advanced_healthcare: "उन्नत स्वास्थ्य देखभाल",
  secure_modern: "सुरक्षित, आधुनिक चिकित्सा रिकॉर्ड प्रबंधन",
}
