export const mr = {
  // Common
  app_name: "मेडचेन",
  loading: "लोड होत आहे...",
  save: "जतन करा",
  cancel: "रद्द करा",
  edit: "संपादित करा",
  delete: "हटवा",
  logout: "साइन आउट",
  copy: "कॉपी करा",
  copied: "क्लिपबोर्डवर कॉपी केले",

  // Home page
  welcome: "रुग्णांच्या वैद्यकीय नोंदी व्यवस्थापित करण्यासाठी एक सुरक्षित प्रणाली",
  for_patients: "रुग्णांसाठी",
  register_manage: "नोंदणी करा आणि आपल्या वैद्यकीय नोंदी व्यवस्थापित करा",
  secure_medical_id: "सुरक्षित वैद्यकीय आयडी",
  secure_medical_id_desc: "आपला वैद्यकीय डेटा प्रगत एन्क्रिप्शनद्वारे संरक्षित",
  control_data: "आपला डेटा नियंत्रित करा",
  control_data_desc: "आपल्या वैद्यकीय नोंदींमध्ये प्रवेश द्या आणि रद्द करा",
  face_id_auth: "फेस आयडी प्रमाणीकरण",
  face_id_auth_desc: "आपल्या आरोग्य डेटामध्ये सुरक्षित आणि सोयीस्कर प्रवेश",
  register_patient: "रुग्ण म्हणून नोंदणी करा",

  for_hospitals: "रुग्णालयांसाठी",
  upload_access: "रुग्णांच्या नोंदी अपलोड आणि प्रवेश करा",
  secure_uploads: "सुरक्षित नोंदी अपलोड",
  secure_uploads_desc: "रुग्णांच्या वैद्यकीय नोंदी सहजपणे अपलोड आणि व्यवस्थापित करा",
  patient_history: "रुग्णांच्या इतिहासात प्रवेश",
  patient_history_desc: "रुग्णाच्या परवानगीने संपूर्ण वैद्यकीय इतिहास पहा",
  staff_auth: "कर्मचारी प्रमाणीकरण",
  staff_auth_desc: "अधिकृत कर्मचाऱ्यांसाठी सुरक्षित बायोमेट्रिक प्रवेश",
  hospital_login: "रुग्णालय लॉगिन",

  // Dashboard
  dashboard: "डॅशबोर्ड",
  personal_profile: "वैयक्तिक प्रोफाइल",
  personal_info: "आपली वैयक्तिक माहिती",
  hospital_profile: "रुग्णालय प्रोफाइल",
  hospital_info: "आपली रुग्णालय माहिती",
  medical_id: "वैद्यकीय आयडी",
  unique_id: "आपला अद्वितीय ओळखकर्ता",
  hospital_id: "रुग्णालय आयडी",
  hospital_identifier: "आपला रुग्णालय ओळखकर्ता",

  // Medical Records
  medical_records: "वैद्यकीय नोंदी",
  no_records: "कोणत्याही वैद्यकीय नोंदी सापडल्या नाहीत",
  no_records_desc: "आपल्याकडे अद्याप कोणत्याही वैद्यकीय नोंदी नाहीत.",
  all: "सर्व",
  diagnosis: "निदान",
  prescription: "औषधपत्र",
  lab_results: "प्रयोगशाळा निकाल",
  imaging: "इमेजिंग",

  // Access Control
  access_control: "प्रवेश नियंत्रण",
  pending_requests: "प्रलंबित प्रवेश विनंत्या",
  hospitals_with_access: "प्रवेश असलेली रुग्णालये",
  active: "सक्रिय",
  no_access: "कोणताही प्रवेश दिलेला नाही",
  no_access_desc: "आपण अद्याप कोणत्याही रुग्णालयाला आपल्या वैद्यकीय नोंदींमध्ये प्रवेश दिलेला नाही.",
  security: "सुरक्षा",
  security_desc:
    "आपल्या प्रवेश नियंत्रण सेटिंग्ज सुरक्षितपणे साठवल्या आहेत. केवळ आपणच आपल्या वैद्यकीय नोंदींमध्ये प्रवेश देऊ किंवा रद्द करू शकता.",
  approve: "मंजूर करा",
  deny: "नाकारा",

  // Patient Search
  patient_search: "रुग्ण शोध",
  search: "शोधा",
  enter_patient_id: "रुग्ण आयडी प्रविष्ट करा",
  patient_not_found: "रुग्ण सापडला नाही. कृपया आयडी तपासा.",
  access_required: "प्रवेश आवश्यक",
  access_required_desc:
    "या रुग्णाच्या वैद्यकीय नोंदी पाहण्यासाठी आपल्याला परवानगी आवश्यक आहे. प्रवेशाची विनंती करा आणि रुग्णाला सूचित केले जाईल.",
  request_access: "प्रवेशाची विनंती करा",
  access_granted: "प्रवेश दिला",
  access_requested: "प्रवेशाची विनंती केली",

  // File Upload
  upload_records: "वैद्यकीय नोंदी अपलोड करा",
  upload_desc: "रुग्णांच्या नोंदी सुरक्षितपणे आमच्या प्रणालीमध्ये अपलोड करा",
  patient_id: "रुग्ण आयडी",
  record_type: "नोंद प्रकार",
  record_title: "नोंद शीर्षक",
  description: "वर्णन (ऐच्छिक)",
  files: "फाइल्स",
  tap_upload: "अपलोड करण्यासाठी टॅप करा",
  file_formats: "PDF, DOC, JPG, PNG, DICOM आणि इतर वैद्यकीय स्वरूपे",
  take_photo: "फोटो काढा",
  uploading: "अपलोड होत आहे...",
  upload_success: "वैद्यकीय नोंदी यशस्वीरित्या अपलोड केल्या आहेत.",

  // Profile
  profile: "प्रोफाइल",
  full_name: "पूर्ण नाव",
  email: "ईमेल पत्ता",
  phone: "मोबाईल नंबर",
  hospital_name: "रुग्णालयाचे नाव",
  address: "पत्ता",
  security_settings: "सुरक्षा सेटिंग्ज",
  face_id_toggle: "जलद आणि सुरक्षित लॉगिनसाठी फेस आयडी वापरा",
  save_changes: "बदल जतन करा",
  saving: "जतन करत आहे...",
  profile_updated: "आपली प्रोफाइल यशस्वीरित्या अपडेट केली आहे",

  // Language
  language: "भाषा",
  english: "English",
  hindi: "हिंदी",
  marathi: "मराठी",
  select_language: "भाषा निवडा",
  language_changed: "भाषा यशस्वीरित्या बदलली",

  // Advanced Healthcare
  advanced_healthcare: "प्रगत आरोग्य सेवा",
  secure_modern: "सुरक्षित, आधुनिक वैद्यकीय नोंदी व्यवस्थापन",
}
