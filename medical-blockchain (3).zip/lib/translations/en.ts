export const en = {
  // Common
  app_name: "MedChain",
  loading: "Loading...",
  save: "Save",
  cancel: "Cancel",
  edit: "Edit",
  delete: "Delete",
  logout: "Sign Out",
  copy: "Copy",
  copied: "Copied to clipboard",

  // Home page
  welcome: "A secure system for managing patient medical records",
  for_patients: "For Patients",
  register_manage: "Register and manage your medical records",
  secure_medical_id: "Secure medical ID",
  secure_medical_id_desc: "Your medical data protected by advanced encryption",
  control_data: "Control your data",
  control_data_desc: "Grant and revoke access to your medical records",
  face_id_auth: "Face ID authentication",
  face_id_auth_desc: "Secure and convenient access to your health data",
  register_patient: "Register as Patient",

  for_hospitals: "For Hospitals",
  upload_access: "Upload and access patient records",
  secure_uploads: "Secure record uploads",
  secure_uploads_desc: "Easily upload and manage patient medical records",
  patient_history: "Patient history access",
  patient_history_desc: "View complete medical history with patient permission",
  staff_auth: "Staff authentication",
  staff_auth_desc: "Secure biometric access for authorized personnel",
  hospital_login: "Hospital Login",

  // Dashboard
  dashboard: "Dashboard",
  personal_profile: "Personal Profile",
  personal_info: "Your personal information",
  hospital_profile: "Hospital Profile",
  hospital_info: "Your hospital information",
  medical_id: "Medical ID",
  unique_id: "Your unique identifier",
  hospital_id: "Hospital ID",
  hospital_identifier: "Your hospital identifier",

  // Medical Records
  medical_records: "Medical Records",
  no_records: "No Medical Records Found",
  no_records_desc: "You don't have any medical records yet.",
  all: "All",
  diagnosis: "Diagnosis",
  prescription: "Prescription",
  lab_results: "Lab Results",
  imaging: "Imaging",

  // Access Control
  access_control: "Access Control",
  pending_requests: "Pending Access Requests",
  hospitals_with_access: "Hospitals with Access",
  active: "Active",
  no_access: "No Access Granted",
  no_access_desc: "You haven't granted any hospitals access to your medical records yet.",
  security: "Security",
  security_desc:
    "Your access control settings are securely stored. Only you can grant or revoke access to your medical records.",
  approve: "Approve",
  deny: "Deny",

  // Patient Search
  patient_search: "Patient Search",
  search: "Search",
  enter_patient_id: "Enter patient ID",
  patient_not_found: "Patient not found. Please check the ID.",
  access_required: "Access Required",
  access_required_desc:
    "You need permission from this patient to view their medical records. Request access and the patient will be notified.",
  request_access: "Request Access",
  access_granted: "Access Granted",
  access_requested: "Access Requested",

  // File Upload
  upload_records: "Upload Medical Records",
  upload_desc: "Upload patient records securely to our system",
  patient_id: "Patient ID",
  record_type: "Record Type",
  record_title: "Record Title",
  description: "Description (Optional)",
  files: "Files",
  tap_upload: "Tap to upload files",
  file_formats: "PDF, DOC, JPG, PNG, DICOM and other medical formats",
  take_photo: "Take Photo",
  uploading: "Uploading...",
  upload_success: "Medical records have been successfully uploaded.",

  // Profile
  profile: "Profile",
  full_name: "Full Name",
  email: "Email Address",
  phone: "Mobile Number",
  hospital_name: "Hospital Name",
  address: "Address",
  security_settings: "Security Settings",
  face_id_toggle: "Use Face ID for quick and secure login",
  save_changes: "Save Changes",
  saving: "Saving...",
  profile_updated: "Your profile has been successfully updated",

  // Language
  language: "Language",
  english: "English",
  hindi: "हिंदी",
  marathi: "मराठी",
  select_language: "Select Language",
  language_changed: "Language changed successfully",

  // Advanced Healthcare
  advanced_healthcare: "Advanced Healthcare",
  secure_modern: "Secure, modern medical record management",
}
