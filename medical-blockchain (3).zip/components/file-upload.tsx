"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { FileIcon, Loader2, Upload, X, FileText, FileImage, Camera } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

interface FileUploadProps {
  hospitalId: string
}

export function FileUpload({ hospitalId }: FileUploadProps) {
  const { translations } = useLanguage()
  const [patientId, setPatientId] = useState("")
  const [recordType, setRecordType] = useState("")
  const [recordTitle, setRecordTitle] = useState("")
  const [description, setDescription] = useState("")
  const [files, setFiles] = useState<File[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [showCamera, setShowCamera] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // Clean up camera resources when component unmounts
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setFiles((prevFiles) => [...prevFiles, ...newFiles])
    }
  }

  const removeFile = (index: number) => {
    setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index))
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const newFiles = Array.from(e.dataTransfer.files)
      setFiles((prevFiles) => [...prevFiles, ...newFiles])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!patientId.trim()) {
      setError(translations.patient_id + " is required")
      return
    }

    if (!recordType) {
      setError(translations.record_type + " is required")
      return
    }

    if (!recordTitle.trim()) {
      setError(translations.record_title + " is required")
      return
    }

    if (files.length === 0) {
      setError("Please upload at least one file")
      return
    }

    setIsUploading(true)
    setError("")
    setSuccess(false)
    setUploadProgress(0)

    try {
      // Simulate upload with progress
      const totalSteps = 10
      for (let i = 1; i <= totalSteps; i++) {
        await new Promise((resolve) => setTimeout(resolve, 300))
        setUploadProgress((i / totalSteps) * 100)
      }

      // Reset form
      setPatientId("")
      setRecordType("")
      setRecordTitle("")
      setDescription("")
      setFiles([])
      setSuccess(true)
    } catch (err) {
      setError("An error occurred during the upload. Please try again.")
    } finally {
      setIsUploading(false)
      setUploadProgress(0)
    }
  }

  const getFileIcon = (file: File) => {
    const fileType = file.type.split("/")[0]
    const fileExtension = file.name.split(".").pop()?.toLowerCase()

    if (fileType === "image") {
      return <FileImage className="h-5 w-5 text-blue-600" />
    } else if (fileExtension === "pdf") {
      return <FileText className="h-5 w-5 text-red-600" />
    } else if (fileExtension === "doc" || fileExtension === "docx") {
      return <FileText className="h-5 w-5 text-blue-600" />
    } else {
      return <FileIcon className="h-5 w-5 text-gray-600" />
    }
  }

  const startCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: "environment" }, // Use back camera by default for document scanning
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
        })

        if (videoRef.current) {
          videoRef.current.srcObject = stream
          streamRef.current = stream
          setShowCamera(true)
        }
      } else {
        setError("Camera access is not supported in your browser")
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("Could not access camera. Please check permissions.")
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        track.stop()
      })
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setShowCamera(false)
  }

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      if (context) {
        // Set canvas dimensions to match video
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight

        // Draw the current video frame on the canvas
        context.drawImage(video, 0, 0, canvas.width, canvas.height)

        // Convert canvas to blob
        canvas.toBlob(
          (blob) => {
            if (blob) {
              // Create a File object from the blob
              const now = new Date()
              const fileName = `photo_${now.getFullYear()}${now.getMonth() + 1}${now.getDate()}_${now.getHours()}${now.getMinutes()}${now.getSeconds()}.jpg`
              const file = new File([blob], fileName, { type: "image/jpeg" })

              // Add the file to the files array
              setFiles((prevFiles) => [...prevFiles, file])

              // Stop the camera after capturing
              stopCamera()
            }
          },
          "image/jpeg",
          0.95,
        ) // High quality JPEG
      }
    }
  }

  return (
    <div className="space-y-6">
      <Card className="ios-card border-0 shadow-md">
        <CardHeader>
          <CardTitle>{translations.upload_records}</CardTitle>
          <CardDescription>{translations.upload_desc}</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="patientId">{translations.patient_id}</Label>
              <Input
                id="patientId"
                placeholder="Enter patient's ID"
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="ios-input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="recordType">{translations.record_type}</Label>
              <Select value={recordType} onValueChange={setRecordType}>
                <SelectTrigger id="recordType" className="ios-input">
                  <SelectValue placeholder="Select record type" />
                </SelectTrigger>
                <SelectContent className="rounded-xl">
                  <SelectItem value="diagnosis">{translations.diagnosis}</SelectItem>
                  <SelectItem value="prescription">{translations.prescription}</SelectItem>
                  <SelectItem value="labResults">{translations.lab_results}</SelectItem>
                  <SelectItem value="imaging">{translations.imaging}</SelectItem>
                  <SelectItem value="surgery">Surgery</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="recordTitle">{translations.record_title}</Label>
              <Input
                id="recordTitle"
                placeholder="Enter a title for this record"
                value={recordTitle}
                onChange={(e) => setRecordTitle(e.target.value)}
                className="ios-input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">{translations.description}</Label>
              <Textarea
                id="description"
                placeholder="Enter additional details about this record"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="ios-input"
              />
            </div>

            <div className="space-y-2">
              <Label>{translations.files}</Label>
              <div className="grid gap-4">
                <div
                  className="flex h-32 cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-gray-300 p-4 text-center transition-colors hover:bg-gray-50"
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                >
                  <Upload className="mb-2 h-6 w-6 text-gray-400" />
                  <p className="text-sm font-medium">{translations.tap_upload}</p>
                  <p className="text-xs text-gray-500">{translations.file_formats}</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={handleFileChange}
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.dcm,.dicom,.txt,.csv,.xls,.xlsx"
                  />
                </div>

                <div className="flex justify-center">
                  <Button
                    type="button"
                    variant="outline"
                    className="flex items-center gap-2 rounded-full"
                    onClick={startCamera}
                  >
                    <Camera className="h-4 w-4" />
                    <span>{translations.take_photo}</span>
                  </Button>
                </div>

                {showCamera && (
                  <div className="rounded-xl bg-black p-2">
                    <div className="aspect-video w-full rounded-lg bg-black">
                      <video ref={videoRef} autoPlay playsInline className="h-full w-full rounded-lg object-cover" />
                      <canvas ref={canvasRef} className="hidden" />
                    </div>
                    <div className="mt-2 flex justify-between">
                      <Button
                        type="button"
                        variant="outline"
                        className="rounded-full bg-white text-red-500"
                        onClick={stopCamera}
                      >
                        <X className="mr-1 h-4 w-4" />
                        Cancel
                      </Button>
                      <button
                        type="button"
                        className="flex h-14 w-14 items-center justify-center rounded-full border-4 border-white bg-white"
                        onClick={capturePhoto}
                      >
                        <div className="h-10 w-10 rounded-full bg-blue-600"></div>
                      </button>
                      <div className="w-20"></div> {/* Spacer for alignment */}
                    </div>
                  </div>
                )}

                {files.length > 0 && (
                  <div className="space-y-2">
                    {files.map((file, index) => (
                      <div key={index} className="flex items-center justify-between rounded-xl border p-3">
                        <div className="flex items-center overflow-hidden">
                          {getFileIcon(file)}
                          <span className="ml-2 truncate text-sm">{file.name}</span>
                          <span className="ml-2 shrink-0 text-xs text-gray-500">
                            {(file.size / 1024 / 1024).toFixed(2)} MB
                          </span>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 shrink-0"
                          onClick={() => removeFile(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {isUploading && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{translations.uploading}</span>
                  <span className="text-sm text-gray-500">{Math.round(uploadProgress)}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2 w-full rounded-full" />
              </div>
            )}

            {error && (
              <Alert variant="destructive" className="rounded-xl">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="rounded-xl bg-green-50 text-green-800">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                  <polyline points="22 4 12 14.01 9 11.01" />
                </svg>
                <AlertTitle>Success</AlertTitle>
                <AlertDescription>{translations.upload_success}</AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter>
            <Button type="submit" className="ios-button w-full" disabled={isUploading}>
              {isUploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {translations.uploading}
                </>
              ) : (
                translations.upload_records
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
