"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { FileText, Home, Key, Search, Upload, User } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

interface TabItem {
  icon: React.ReactNode
  label: string
  href: string
}

interface IOSTabBarProps {
  userType: "patient" | "hospital" | "none"
}

export function IOSTabBar({ userType }: IOSTabBarProps) {
  const pathname = usePathname()
  const { translations } = useLanguage()

  const getPatientTabs = (): TabItem[] => [
    {
      icon: <Home className="h-6 w-6" />,
      label: translations.dashboard,
      href: "/patient/dashboard",
    },
    {
      icon: <FileText className="h-6 w-6" />,
      label: translations.medical_records,
      href: "/patient/dashboard?tab=records",
    },
    {
      icon: <Key className="h-6 w-6" />,
      label: translations.access_control,
      href: "/patient/dashboard?tab=access",
    },
    {
      icon: <User className="h-6 w-6" />,
      label: translations.profile,
      href: "/patient/profile",
    },
  ]

  const getHospitalTabs = (): TabItem[] => [
    {
      icon: <Home className="h-6 w-6" />,
      label: translations.dashboard,
      href: "/hospital/dashboard",
    },
    {
      icon: <Search className="h-6 w-6" />,
      label: translations.search,
      href: "/hospital/dashboard?tab=search",
    },
    {
      icon: <Upload className="h-6 w-6" />,
      label: translations.upload_records,
      href: "/hospital/dashboard?tab=upload",
    },
    {
      icon: <User className="h-6 w-6" />,
      label: translations.profile,
      href: "/hospital/profile",
    },
  ]

  const getGuestTabs = (): TabItem[] => [
    {
      icon: <Home className="h-6 w-6" />,
      label: translations.app_name,
      href: "/",
    },
    {
      icon: <User className="h-6 w-6" />,
      label: translations.for_patients,
      href: "/patient/login",
    },
    {
      icon: <FileText className="h-6 w-6" />,
      label: translations.for_hospitals,
      href: "/hospital/login",
    },
  ]

  const tabs = userType === "patient" ? getPatientTabs() : userType === "hospital" ? getHospitalTabs() : getGuestTabs()

  return (
    <div className="fixed bottom-0 left-0 right-0 z-10 bg-white pb-safe shadow-[0_-1px_2px_rgba(0,0,0,0.1)]">
      <div className="flex h-14 items-center justify-around">
        {tabs.map((tab) => {
          const isActive =
            pathname === tab.href ||
            pathname.startsWith(tab.href.split("?")[0]) ||
            (tab.href.includes("profile") && pathname.includes("profile"))

          return (
            <Link
              key={tab.href}
              href={tab.href}
              className={cn(
                "flex h-full w-full flex-col items-center justify-center space-y-1 transition-colors",
                isActive ? "text-blue-600" : "text-gray-600",
              )}
            >
              {tab.icon}
              <span className="text-xs">{tab.label}</span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
