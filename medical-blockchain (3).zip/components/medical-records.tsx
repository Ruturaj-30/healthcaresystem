"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileIcon, FileText, Download, ChevronRight } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

interface MedicalRecordsProps {
  patientId: string
}

interface Record {
  id: string
  type: string
  title: string
  date: string
  hospital: string
  files: {
    name: string
    size: string
    type: string
  }[]
}

export function MedicalRecords({ patientId }: MedicalRecordsProps) {
  const [records, setRecords] = useState<Record[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedRecord, setSelectedRecord] = useState<Record | null>(null)
  const { translations } = useLanguage()

  useEffect(() => {
    // Simulate fetching records from blockchain
    const fetchRecords = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1500))

        // Mock data - keeping medical record content in English
        setRecords([
          {
            id: "rec1",
            type: "diagnosis",
            title: "Annual Physical Examination",
            date: "2023-10-15",
            hospital: "General Hospital",
            files: [
              { name: "physical_exam_report.pdf", size: "1.2 MB", type: "pdf" },
              { name: "blood_pressure_chart.jpg", size: "0.8 MB", type: "image" },
            ],
          },
          {
            id: "rec2",
            type: "prescription",
            title: "Medication for Hypertension",
            date: "2023-09-22",
            hospital: "Heart Clinic",
            files: [{ name: "prescription_details.pdf", size: "0.5 MB", type: "pdf" }],
          },
          {
            id: "rec3",
            type: "labResults",
            title: "Blood Work Analysis",
            date: "2023-08-05",
            hospital: "Medical Laboratory Inc.",
            files: [
              { name: "blood_work_results.pdf", size: "2.1 MB", type: "pdf" },
              { name: "cholesterol_chart.png", size: "0.6 MB", type: "image" },
            ],
          },
          {
            id: "rec4",
            type: "imaging",
            title: "Chest X-Ray",
            date: "2023-07-18",
            hospital: "Imaging Center",
            files: [
              { name: "chest_xray.dcm", size: "15.4 MB", type: "dicom" },
              { name: "radiologist_report.pdf", size: "0.9 MB", type: "pdf" },
            ],
          },
        ])
      } catch (error) {
        console.error("Error fetching records:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchRecords()
  }, [patientId])

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-blue-200 border-t-blue-600"></div>
          <p>{translations.loading}</p>
        </div>
      </div>
    )
  }

  if (records.length === 0) {
    return (
      <div className="flex h-64 flex-col items-center justify-center rounded-xl border border-dashed p-8 text-center">
        <FileText className="mb-4 h-12 w-12 text-gray-400" />
        <h3 className="mb-2 text-lg font-medium">{translations.no_records}</h3>
        <p className="text-sm text-gray-500">{translations.no_records_desc}</p>
      </div>
    )
  }

  const recordsByType = {
    all: records,
    diagnosis: records.filter((r) => r.type === "diagnosis"),
    prescription: records.filter((r) => r.type === "prescription"),
    labResults: records.filter((r) => r.type === "labResults"),
    imaging: records.filter((r) => r.type === "imaging"),
  }

  if (selectedRecord) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" className="flex items-center text-blue-600" onClick={() => setSelectedRecord(null)}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="mr-1 h-4 w-4"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m15 18-6-6 6-6" />
          </svg>
          Back to Records
        </Button>

        <Card className="ios-card border-0 shadow-md">
          <CardContent className="p-4">
            <div className="mb-4">
              <RecordTypeBadge type={selectedRecord.type} />
              <h3 className="mt-2 text-lg font-semibold">{selectedRecord.title}</h3>
              <div className="mt-1 flex items-center text-sm text-gray-600">
                <span>{selectedRecord.date}</span>
                <span className="mx-2">•</span>
                <span>{selectedRecord.hospital}</span>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium">{translations.files}</h4>
              {selectedRecord.files.map((file, index) => (
                <div key={index} className="flex items-center justify-between rounded-xl bg-gray-50 p-3">
                  <div className="flex items-center">
                    <FileTypeIcon type={file.type} />
                    <div className="ml-3">
                      <p className="font-medium">{file.name}</p>
                      <p className="text-xs text-gray-500">{file.size}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="flex w-full overflow-x-auto rounded-xl">
          <TabsTrigger value="all" className="flex-1">
            {translations.all}
          </TabsTrigger>
          <TabsTrigger value="diagnosis" className="flex-1">
            {translations.diagnosis}
          </TabsTrigger>
          <TabsTrigger value="prescription" className="flex-1">
            {translations.prescription}
          </TabsTrigger>
          <TabsTrigger value="labResults" className="flex-1">
            {translations.lab_results}
          </TabsTrigger>
          <TabsTrigger value="imaging" className="flex-1">
            {translations.imaging}
          </TabsTrigger>
        </TabsList>

        {Object.entries(recordsByType).map(([type, records]) => (
          <TabsContent key={type} value={type} className="mt-6 space-y-4">
            {records.length === 0 ? (
              <div className="flex h-32 items-center justify-center rounded-xl border border-dashed p-4 text-center">
                <p className="text-sm text-gray-500">No {type} records found</p>
              </div>
            ) : (
              records.map((record) => (
                <Card key={record.id} className="ios-card border-0 shadow-sm">
                  <CardContent className="p-4">
                    <button
                      className="flex w-full items-center justify-between"
                      onClick={() => setSelectedRecord(record)}
                    >
                      <div>
                        <RecordTypeBadge type={record.type} />
                        <h3 className="mt-1 font-medium">{record.title}</h3>
                        <div className="mt-1 flex items-center text-sm text-gray-600">
                          <span>{record.date}</span>
                          <span className="mx-2">•</span>
                          <span>{record.hospital}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    </button>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

function RecordTypeBadge({ type }: { type: string }) {
  const { translations } = useLanguage()
  let color = "bg-gray-100 text-gray-800"
  let label = "Unknown"

  switch (type) {
    case "diagnosis":
      color = "bg-blue-100 text-blue-800"
      label = translations.diagnosis
      break
    case "prescription":
      color = "bg-green-100 text-green-800"
      label = translations.prescription
      break
    case "labResults":
      color = "bg-purple-100 text-purple-800"
      label = translations.lab_results
      break
    case "imaging":
      color = "bg-amber-100 text-amber-800"
      label = translations.imaging
      break
  }

  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${color}`}>{label}</span>
  )
}

function FileTypeIcon({ type }: { type: string }) {
  switch (type) {
    case "pdf":
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5 text-red-600"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
          <path d="M9 15h6" />
          <path d="M9 11h6" />
        </svg>
      )
    case "image":
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5 text-blue-600"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
          <circle cx="8.5" cy="8.5" r="1.5" />
          <polyline points="21 15 16 10 5 21" />
        </svg>
      )
    case "dicom":
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5 text-purple-600"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
          <polyline points="14 2 14 8 20 8" />
          <circle cx="10" cy="13" r="2" />
          <path d="m20 17-3.5-3.5-2 2-3-3-3 3" />
        </svg>
      )
    default:
      return <FileIcon className="h-5 w-5 text-gray-600" />
  }
}
