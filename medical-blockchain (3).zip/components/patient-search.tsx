"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, Search, ShieldAlert, ShieldCheck } from "lucide-react"

interface PatientSearchProps {
  hospitalId: string
}

interface PatientRecord {
  id: string
  name: string
  hasAccess: boolean
  records: {
    id: string
    type: string
    date: string
    title: string
    hospital: string
  }[]
}

export function PatientSearch({ hospitalId }: PatientSearchProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResult, setSearchResult] = useState<PatientRecord | null>(null)
  const [error, setError] = useState("")

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!searchQuery.trim()) {
      setError("Please enter a patient ID")
      return
    }

    setIsSearching(true)
    setError("")

    try {
      // Simulate search
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // For demo purposes, create mock data
      if (searchQuery.startsWith("MED")) {
        const hasAccess = Math.random() > 0.3 // 70% chance of having access

        setSearchResult({
          id: searchQuery,
          name: "John Doe",
          hasAccess,
          records: hasAccess
            ? [
                {
                  id: "rec1",
                  type: "Diagnosis",
                  date: "2023-10-15",
                  title: "Annual Physical Examination",
                  hospital: "General Hospital",
                },
                {
                  id: "rec2",
                  type: "Prescription",
                  date: "2023-09-22",
                  title: "Medication for Hypertension",
                  hospital: "Heart Clinic",
                },
                {
                  id: "rec3",
                  type: "Lab Results",
                  date: "2023-08-05",
                  title: "Blood Work Analysis",
                  hospital: "Medical Laboratory Inc.",
                },
              ]
            : [],
        })
      } else {
        setError("Patient not found. Please check the ID.")
        setSearchResult(null)
      }
    } catch (err) {
      setError("An error occurred during the search. Please try again.")
    } finally {
      setIsSearching(false)
    }
  }

  const requestAccess = async () => {
    try {
      // Simulate access request
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Update the search result to show pending access
      setSearchResult((prev) => {
        if (!prev) return null
        return {
          ...prev,
          hasAccess: false,
          accessRequested: true,
        }
      })
    } catch (err) {
      setError("Failed to request access. Please try again.")
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <form onSubmit={handleSearch} className="flex w-full items-center space-x-2">
            <Input
              placeholder="Enter patient ID"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" disabled={isSearching}>
              {isSearching ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Searching...
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" /> Search
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {error && (
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {searchResult && (
        <div className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{searchResult.name}</h3>
                  <p className="text-sm text-muted-foreground">ID: {searchResult.id}</p>
                </div>
                <div className="flex items-center">
                  {searchResult.hasAccess ? (
                    <div className="flex items-center text-green-600">
                      <ShieldCheck className="mr-2 h-5 w-5" />
                      <span>Access Granted</span>
                    </div>
                  ) : searchResult.accessRequested ? (
                    <div className="flex items-center text-amber-600">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="mr-2 h-5 w-5"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <circle cx="12" cy="12" r="10" />
                        <line x1="12" y1="8" x2="12" y2="12" />
                        <line x1="12" y1="16" x2="12.01" y2="16" />
                      </svg>
                      <span>Access Requested</span>
                    </div>
                  ) : (
                    <Button onClick={requestAccess}>Request Access</Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {searchResult.hasAccess && searchResult.records.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Medical Records</h3>
              {searchResult.records.map((record) => (
                <Card key={record.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center">
                          <Badge type={record.type} />
                          <h4 className="ml-2 font-medium">{record.title}</h4>
                        </div>
                        <div className="mt-1 flex items-center text-sm text-muted-foreground">
                          <span>{record.date}</span>
                          <span className="mx-2">•</span>
                          <span>{record.hospital}</span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {!searchResult.hasAccess && (
            <Alert>
              <ShieldAlert className="h-4 w-4" />
              <AlertTitle>Access Required</AlertTitle>
              <AlertDescription>
                You need permission from this patient to view their medical records. Request access and the patient will
                be notified.
              </AlertDescription>
            </Alert>
          )}
        </div>
      )}
    </div>
  )
}

function Badge({ type }: { type: string }) {
  let color = "bg-gray-100 text-gray-800"

  switch (type.toLowerCase()) {
    case "diagnosis":
      color = "bg-blue-100 text-blue-800"
      break
    case "prescription":
      color = "bg-green-100 text-green-800"
      break
    case "lab results":
      color = "bg-purple-100 text-purple-800"
      break
    case "imaging":
      color = "bg-amber-100 text-amber-800"
      break
  }

  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${color}`}>{type}</span>
  )
}
