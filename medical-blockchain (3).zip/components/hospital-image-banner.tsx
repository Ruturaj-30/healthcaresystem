"use client"

import Image from "next/image"
import { useLanguage } from "@/lib/language-context"

interface HospitalImageBannerProps {
  className?: string
}

export function HospitalImageBanner({ className }: HospitalImageBannerProps) {
  const { translations } = useLanguage()

  // Use a placeholder URL that's guaranteed to exist
  const imageSrc = "/placeholder.svg?height=400&width=800"

  return (
    <div className={`relative w-full overflow-hidden rounded-xl ${className}`}>
      <div className="aspect-[16/9] w-full">
        <Image
          src={imageSrc || "/placeholder.svg"}
          alt="Modern hospital building"
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 p-4 text-white">
          <h2 className="text-xl font-bold md:text-2xl">{translations.advanced_healthcare}</h2>
          <p className="text-sm md:text-base">{translations.secure_modern}</p>
        </div>
      </div>
    </div>
  )
}
