"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"

interface MobileMenuProps {
  isLoggedIn: boolean
  isPatient?: boolean
  onLogout?: () => void
}

export function MobileMenu({ isLoggedIn, isPatient, onLogout }: MobileMenuProps) {
  const [open, setOpen] = useState(false)

  const handleLogout = () => {
    if (onLogout) {
      onLogout()
    }
    setOpen(false)
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[80%] sm:w-[350px]">
        <SheetHeader className="border-b pb-4">
          <SheetTitle className="text-left text-xl font-bold text-blue-600">MedChain</SheetTitle>
        </SheetHeader>
        <div className="mt-6 flex flex-col space-y-3">
          <Link href="/" className="py-2 text-lg" onClick={() => setOpen(false)}>
            Home
          </Link>

          {!isLoggedIn && (
            <>
              <Link href="/patient/login" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Patient Login
              </Link>
              <Link href="/patient/register" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Patient Registration
              </Link>
              <Link href="/hospital/login" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Hospital Login
              </Link>
            </>
          )}

          {isLoggedIn && isPatient && (
            <>
              <Link href="/patient/dashboard" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Dashboard
              </Link>
              <Link href="/patient/records" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Medical Records
              </Link>
              <Link href="/patient/access" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Access Control
              </Link>
            </>
          )}

          {isLoggedIn && !isPatient && (
            <>
              <Link href="/hospital/dashboard" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Dashboard
              </Link>
              <Link href="/hospital/search" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Patient Search
              </Link>
              <Link href="/hospital/upload" className="py-2 text-lg" onClick={() => setOpen(false)}>
                Upload Records
              </Link>
            </>
          )}

          {isLoggedIn && (
            <Button variant="destructive" className="mt-4" onClick={handleLogout}>
              Logout
            </Button>
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}
