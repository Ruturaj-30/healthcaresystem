"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { HospitalIcon, ShieldAlert, ShieldCheck, Clock } from "lucide-react"

interface AccessControlProps {
  patientId: string
}

interface AccessRequest {
  id: string
  hospitalId: string
  hospitalName: string
  requestDate: string
  status: "pending" | "approved" | "denied"
}

interface Hospital {
  id: string
  name: string
  hasAccess: boolean
  lastAccessed: string
}

export function AccessControl({ patientId }: AccessControlProps) {
  const [accessRequests, setAccessRequests] = useState<AccessRequest[]>([])
  const [hospitals, setHospitals] = useState<Hospital[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching data
    const fetchData = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1500))

        // Mock data
        setAccessRequests([
          {
            id: "req1",
            hospitalId: "H123456",
            hospitalName: "City Medical Center",
            requestDate: "2023-10-18",
            status: "pending",
          },
          {
            id: "req2",
            hospitalId: "H789012",
            hospitalName: "University Hospital",
            requestDate: "2023-10-15",
            status: "pending",
          },
        ])

        setHospitals([
          {
            id: "H345678",
            name: "General Hospital",
            hasAccess: true,
            lastAccessed: "2023-10-10",
          },
          {
            id: "H901234",
            name: "Heart Clinic",
            hasAccess: true,
            lastAccessed: "2023-09-25",
          },
          {
            id: "H567890",
            name: "Medical Laboratory Inc.",
            hasAccess: true,
            lastAccessed: "2023-08-15",
          },
        ])
      } catch (error) {
        console.error("Error fetching access data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [patientId])

  const handleAccessToggle = (hospitalId: string, newValue: boolean) => {
    // Update hospitals list
    setHospitals(
      hospitals.map((hospital) => (hospital.id === hospitalId ? { ...hospital, hasAccess: newValue } : hospital)),
    )

    // In a real app, this would update the database
  }

  const handleRequestAction = (requestId: string, approved: boolean) => {
    // Update request status
    setAccessRequests(
      accessRequests.map((request) => {
        if (request.id === requestId) {
          const status = approved ? "approved" : "denied"

          // If approved, add to hospitals with access
          if (approved) {
            const requestedHospital = accessRequests.find((r) => r.id === requestId)
            if (requestedHospital && !hospitals.some((h) => h.id === requestedHospital.hospitalId)) {
              setHospitals([
                ...hospitals,
                {
                  id: requestedHospital.hospitalId,
                  name: requestedHospital.hospitalName,
                  hasAccess: true,
                  lastAccessed: new Date().toISOString().split("T")[0],
                },
              ])
            }
          }

          return { ...request, status }
        }
        return request
      }),
    )

    // In a real app, this would update the database
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-blue-200 border-t-blue-600"></div>
          <p>Loading access control data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {accessRequests.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Pending Access Requests</h3>

          {accessRequests
            .filter((r) => r.status === "pending")
            .map((request) => (
              <Card key={request.id} className="ios-card border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex flex-col space-y-4">
                    <div>
                      <div className="flex items-center">
                        <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                          <HospitalIcon className="h-4 w-4 text-blue-600" />
                        </div>
                        <h4 className="font-medium">{request.hospitalName}</h4>
                      </div>
                      <div className="mt-1 ml-11 text-sm text-gray-600">
                        <p>ID: {request.hospitalId}</p>
                        <p>Requested: {request.requestDate}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="outline"
                        className="rounded-full"
                        onClick={() => handleRequestAction(request.id, false)}
                      >
                        Deny
                      </Button>
                      <Button className="rounded-full" onClick={() => handleRequestAction(request.id, true)}>
                        Approve
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

          {accessRequests.filter((r) => r.status !== "pending").length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Recent Actions</h4>
              {accessRequests
                .filter((r) => r.status !== "pending")
                .map((request) => (
                  <div key={request.id} className="flex items-center justify-between rounded-xl bg-gray-50 p-3">
                    <div className="flex items-center">
                      <StatusBadge status={request.status} />
                      <span className="ml-2">{request.hospitalName}</span>
                    </div>
                    <span className="text-sm text-gray-500">{request.requestDate}</span>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium">Hospitals with Access</h3>
          <Badge variant="outline" className="px-2 py-1">
            {hospitals.filter((h) => h.hasAccess).length} Active
          </Badge>
        </div>

        {hospitals.length === 0 ? (
          <Alert className="rounded-xl">
            <Clock className="h-4 w-4" />
            <AlertTitle>No Access Granted</AlertTitle>
            <AlertDescription>
              You haven&apos;t granted any hospitals access to your medical records yet.
            </AlertDescription>
          </Alert>
        ) : (
          hospitals.map((hospital) => (
            <Card key={hospital.id} className="ios-card border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center">
                      <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                        <HospitalIcon className="h-4 w-4 text-blue-600" />
                      </div>
                      <h4 className="font-medium">{hospital.name}</h4>
                    </div>
                    <div className="mt-1 ml-11 text-sm text-gray-600">
                      <p>ID: {hospital.id}</p>
                      <p>Last accessed: {hospital.lastAccessed}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{hospital.hasAccess ? "On" : "Off"}</span>
                    <Switch
                      checked={hospital.hasAccess}
                      onCheckedChange={(checked) => handleAccessToggle(hospital.id, checked)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}

        <Alert className="rounded-xl bg-blue-50">
          <ShieldCheck className="h-4 w-4 text-blue-600" />
          <AlertTitle>Security</AlertTitle>
          <AlertDescription>
            Your access control settings are securely stored. Only you can grant or revoke access to your medical
            records.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case "approved":
      return (
        <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
          <ShieldCheck className="mr-1 h-3 w-3" />
          Approved
        </span>
      )
    case "denied":
      return (
        <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800">
          <ShieldAlert className="mr-1 h-3 w-3" />
          Denied
        </span>
      )
    default:
      return (
        <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800">
          <Clock className="mr-1 h-3 w-3" />
          Pending
        </span>
      )
  }
}
