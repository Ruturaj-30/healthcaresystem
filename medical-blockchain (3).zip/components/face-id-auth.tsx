"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Fingerprint, Camera, X } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

interface FaceIDAuthProps {
  onAuthenticate: () => void
  onCancel: () => void
}

export function FaceIDAuth({ onAuthenticate, onCancel }: FaceIDAuthProps) {
  const { translations } = useLanguage()
  const [isSupported, setIsSupported] = useState(false)
  const [isAuthenticating, setIsAuthenticating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [cameraActive, setCameraActive] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  useEffect(() => {
    // Check if Web Authentication API is supported
    const checkSupport = async () => {
      if (
        window.PublicKeyCredential &&
        window.navigator.credentials &&
        window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable
      ) {
        try {
          const available = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
          setIsSupported(available)
        } catch (err) {
          setIsSupported(false)
        }
      }
    }

    checkSupport()

    // Cleanup function to stop camera when component unmounts
    return () => {
      stopCamera()
    }
  }, [])

  const startCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const constraints = {
          video: {
            facingMode: "user", // Use front camera for face authentication
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
        }

        const stream = await navigator.mediaDevices.getUserMedia(constraints)

        if (videoRef.current) {
          videoRef.current.srcObject = stream
          streamRef.current = stream
          setCameraActive(true)
        }
      } else {
        setError("Camera access is not supported in your browser")
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("Could not access camera. Please check permissions.")
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        track.stop()
      })
      streamRef.current = null
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null
    }

    setCameraActive(false)
  }

  const startAuthentication = async () => {
    setIsAuthenticating(true)
    setError(null)

    try {
      // Start camera for face authentication
      await startCamera()

      // Simulate face scanning process
      await new Promise((resolve) => setTimeout(resolve, 3000))

      // Stop camera after authentication
      stopCamera()

      // Simulate successful authentication
      onAuthenticate()
    } catch (err) {
      setError("Authentication failed. Please try again.")
      stopCamera()
    } finally {
      setIsAuthenticating(false)
    }
  }

  const handleCancel = () => {
    stopCamera()
    onCancel()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-xs rounded-2xl bg-white p-6 text-center">
        {cameraActive ? (
          <div className="relative mb-4">
            <video ref={videoRef} autoPlay playsInline className="h-64 w-full rounded-xl bg-black object-cover" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-40 w-40 rounded-full border-4 border-dashed border-blue-400 opacity-70"></div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-2 h-8 w-8 rounded-full bg-white/80"
              onClick={stopCamera}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="mb-4 flex justify-center">
            {isAuthenticating ? (
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-100">
                <div className="h-8 w-8 animate-pulse rounded-full bg-blue-600"></div>
              </div>
            ) : (
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-100">
                <Fingerprint className="h-8 w-8 text-blue-600" />
              </div>
            )}
          </div>
        )}

        <h3 className="mb-2 text-lg font-semibold">
          {cameraActive
            ? "Position your face in the circle"
            : isAuthenticating
              ? "Authenticating..."
              : "Face ID Authentication"}
        </h3>

        <p className="mb-4 text-sm text-gray-600">
          {cameraActive
            ? "Please look directly at the camera"
            : isAuthenticating
              ? "Please look at your device"
              : isSupported
                ? "Use Face ID to quickly and securely access your account"
                : "Your device doesn't support Face ID. Please use password authentication."}
        </p>

        {error && <p className="mb-4 text-sm text-red-600">{error}</p>}

        <div className="flex flex-col space-y-2">
          {!isAuthenticating && !cameraActive && (
            <>
              {isSupported && (
                <Button onClick={startAuthentication} className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                  <Camera className="mr-2 h-4 w-4" />
                  {translations.face_id_auth}
                </Button>
              )}
              <Button variant="outline" onClick={handleCancel} className="w-full rounded-full">
                {isSupported ? "Use Password Instead" : "Continue with Password"}
              </Button>
            </>
          )}

          {cameraActive && (
            <Button variant="outline" onClick={stopCamera} className="w-full rounded-full">
              Cancel Scan
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
