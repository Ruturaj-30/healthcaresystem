"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Globe } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { useToast } from "@/components/ui/use-toast"

export function LanguageSelector() {
  const { language, setLanguage, translations } = useLanguage()
  const { toast } = useToast()
  const [isOpen, setIsOpen] = useState(false)

  const handleLanguageChange = (lang: string) => {
    setLanguage(lang)
    setIsOpen(false)
    toast({
      title: translations.language_changed,
      duration: 2000,
    })
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="flex items-center gap-1 h-9 rounded-full">
          <Globe className="h-4 w-4" />
          <span className="hidden sm:inline">{translations.language}</span>
          <span className="inline sm:hidden">{language === "en" ? "🇬🇧" : language === "hi" ? "🇮🇳" : "🇮🇳"}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40">
        <DropdownMenuItem className={language === "en" ? "bg-muted" : ""} onClick={() => handleLanguageChange("en")}>
          <span className="mr-2">🇬🇧</span> {translations.english}
        </DropdownMenuItem>
        <DropdownMenuItem className={language === "hi" ? "bg-muted" : ""} onClick={() => handleLanguageChange("hi")}>
          <span className="mr-2">🇮🇳</span> {translations.hindi}
        </DropdownMenuItem>
        <DropdownMenuItem className={language === "mr" ? "bg-muted" : ""} onClick={() => handleLanguageChange("mr")}>
          <span className="mr-2">🇮🇳</span> {translations.marathi}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
