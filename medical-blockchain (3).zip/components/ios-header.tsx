"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ChevronLeft, MoreHorizontal } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { LanguageSelector } from "@/components/language-selector"
import { useLanguage } from "@/lib/language-context"

interface IOSHeaderProps {
  title: string
  showBackButton?: boolean
  backUrl?: string
  isLoggedIn?: boolean
  onLogout?: () => void
  userType?: "patient" | "hospital"
}

export function IOSHeader({
  title,
  showBackButton = false,
  backUrl = "/",
  isLoggedIn = false,
  onLogout,
  userType,
}: IOSHeaderProps) {
  const router = useRouter()
  const { translations } = useLanguage()
  const [isInstallPromptShown, setIsInstallPromptShown] = useState(false)

  const handleBack = () => {
    router.push(backUrl)
  }

  const showInstallPrompt = () => {
    setIsInstallPromptShown(true)
  }

  return (
    <header className="sticky top-0 z-10 bg-white pb-2 pt-safe">
      <div className="flex h-11 items-center justify-between px-4">
        {showBackButton ? (
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={handleBack}>
            <ChevronLeft className="h-5 w-5" />
          </Button>
        ) : (
          <div className="w-9"></div>
        )}

        <h1 className="text-center text-lg font-semibold">{title}</h1>

        <div className="flex items-center gap-1">
          <LanguageSelector />

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <MoreHorizontal className="h-5 w-5" />
                <span className="sr-only">Menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link href="/">{translations.app_name}</Link>
              </DropdownMenuItem>

              {userType === "patient" && (
                <>
                  <DropdownMenuItem asChild>
                    <Link href="/patient/dashboard">{translations.dashboard}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/patient/dashboard?tab=records">{translations.medical_records}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/patient/dashboard?tab=access">{translations.access_control}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/patient/profile">{translations.profile}</Link>
                  </DropdownMenuItem>
                </>
              )}

              {userType === "hospital" && (
                <>
                  <DropdownMenuItem asChild>
                    <Link href="/hospital/dashboard">{translations.dashboard}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/hospital/dashboard?tab=search">{translations.patient_search}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/hospital/dashboard?tab=upload">{translations.upload_records}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/hospital/profile">{translations.profile}</Link>
                  </DropdownMenuItem>
                </>
              )}

              <DropdownMenuItem onClick={showInstallPrompt}>Install on iOS</DropdownMenuItem>

              {isLoggedIn && onLogout && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onLogout} className="text-red-600">
                    {translations.logout}
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {isInstallPromptShown && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="max-w-md rounded-2xl bg-white p-6">
            <h3 className="mb-2 text-lg font-semibold">Install MedChain on iOS</h3>
            <div className="mb-4 space-y-2 text-sm">
              <p>To install this app on your iPhone:</p>
              <ol className="ml-5 list-decimal space-y-2">
                <li>Tap the Share button in Safari</li>
                <li>Scroll down and tap &quot;Add to Home Screen&quot;</li>
                <li>Tap &quot;Add&quot; in the top right corner</li>
              </ol>
            </div>
            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setIsInstallPromptShown(false)}>
                {translations.cancel}
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
